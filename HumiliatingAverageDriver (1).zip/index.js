let companies= 
`[
  {
   "name":"google",
   "employees":10,
   "ceo":"Mary",
   "rating":3.6 
  },
  {
   "name":"startup",
   "employees":3,
   "ceo":null,
   "rating":4.0 
  }
]`

let parse=(companies)=>{
  console.log(JSON.parse(companies))
}
parse(companies);

let bestrating=(companies)=>
{
  console.log("The best rated company has a"+ "" + JSON.parse(companies)[1].rating)
}
bestrating(companies);