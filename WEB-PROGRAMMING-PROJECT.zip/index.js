let companies= 
`[
  {
   "name":"google",
   "num of employees":10,
   "ceo":"Mary",
   "rating":3.6 
  },
  {
   "name":"startup",
   "num of employees":3,
   "ceo":null,
   "rating":4.0 
  }
]`

  let parse=(companies)=>
  {
    console.log(JSON.parse(companies))
  }
  parse(companies);

  let bestrating=(companies)=>
  {
    console.log("The best rated company has a " + JSON.parse(companies)[1].rating)
  }
bestrating(companies);